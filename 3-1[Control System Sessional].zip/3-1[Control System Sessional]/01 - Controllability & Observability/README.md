# Experiment Name: Investigation of the Controllability and Observability of a System

## System Representation:
![alt text](https://github.com/Bakar31/RUET-Sessional-Codes/blob/master/3-1%5BControl%20System%20Sessional%5D/01%20-%20Controllability%20%26%20Observability/system%20representation.jpg)

## Output for Controllability check:
![alt text](https://github.com/Bakar31/RUET-Sessional-Codes/blob/master/3-1%5BControl%20System%20Sessional%5D/01%20-%20Controllability%20%26%20Observability/controllability%20output.jpg)

## Output for Observability check:
![alt text](https://github.com/Bakar31/RUET-Sessional-Codes/blob/master/3-1%5BControl%20System%20Sessional%5D/01%20-%20Controllability%20%26%20Observability/observablility%20output.jpg)